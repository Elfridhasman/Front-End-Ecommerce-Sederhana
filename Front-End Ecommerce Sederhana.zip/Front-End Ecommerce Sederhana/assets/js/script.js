// fungsi untuk menampilkan konfirmasi pemesanan
function getValue() {
    var nama = document.getElementById('nama').value;
    var email = document.getElementById('email').value;
    var propinsi = document.getElementById('propinsi');
    var prop = propinsi.options[propinsi.selectedIndex].text;
    var kota = document.getElementById('kota');
    var kt = kota.options[kota.selectedIndex].text;
    var alamat = document.getElementById('alamat').value;
    var jasakirim = document.getElementById('jasakirim');
    var jasa = jasakirim.options[jasakirim.selectedIndex].text;
    confirm(innerHTML = 'Data Pesanan Anda!\n\nTekan "Oke" jika benar - "Batal" jika salah \n\n' + 'Nama : ' + nama + '\n' + 'Email : ' + email + '\n' + 'Propinsi : ' + prop + '\n' + 'Kota : ' + kt + '\n' + 'Alamat : ' + alamat + '\n' + 'Jasa Pengiriman : ' + jasa);
}